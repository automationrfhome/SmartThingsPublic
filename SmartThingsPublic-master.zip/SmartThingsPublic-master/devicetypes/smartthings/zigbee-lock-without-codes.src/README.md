# Danalock ZigBee 

Local Execution

Works with: 

* [Danalock V3 858125000074](https://danalock.com/products/danalock-v3-smart-lock/)

## Table of contents

* [Capabilities](#capabilities)
* [Device Health](#device-health)

## Capabilities

* **Configuration**
* **Health Check** 
* **Sensor**
* **Battery**
* **Actuator**
* **Lock**
* **Refresh**

## Device Health
* __122 min__ checkInterval

