# Samsung SDS ZigBee doorlock

Local Execution

Works with: 

* [SHP-DP728](https://smarthome.samsungsds.com/doorlock/product/view?prdId=2&searchWord=&searchPrdType=SD&searchCateId1=4&searchCateId2=0&locale=cn)
* [SHP-DP738](https://smarthome.samsungsds.com/doorlock/product/view?prdId=32&searchWord=&searchPrdType=SD&searchCateId1=4&searchCateId2=0&locale=cn)

## Table of contents

* [Capabilities](#capabilities)
* [Device Health](#device-health)

## Capabilities

* **Configuration**
* **Health Check** 
* **Battery**
* **Actuator**
* **Lock**
* **Refresh**

## Device Health
* __122 min__ checkInterval

